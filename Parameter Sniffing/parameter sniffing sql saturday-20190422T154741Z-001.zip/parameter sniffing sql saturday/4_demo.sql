
-- Demo Scripts Adapted from 
-- SQL SERVER MVP DEEP DIVES, Chapter 8 'Parameter Sniffing: your best friend...except when it isn't'
-- by Grant Fritchey  

USE AdventureWorks2008R2;
GO

-- stored proc using local variables
CREATE PROCEDURE dbo.spAddressByCity_local @City NVARCHAR(30)
AS
BEGIN

DECLARE @l_City NVARCHAR(30);

SET @l_City = @City;

SELECT a.AddressID,
a.AddressLine1,
a.AddressLine2,
a.City,
sp.[Name] AS StateProvinceName,
a.PostalCode
FROM Person.Address AS a
JOIN Person.StateProvince AS sp
ON a.StateProvinceID = sp.StateProvinceID
WHERE a.City = @l_City ;
END;
GO

-- Local variables are used : No Parameter Sniffing
-- constant execution plan for any input value

SET STATISTICS IO ON

SET STATISTICS TIME ON

DBCC FREEPROCCACHE;
GO

EXEC dbo.spAddressByCity_local 'London';
GO
-- This plan is sub optimal for London : 1 Index Scan & 1 Index Seek
-- 1100 logical reads

EXEC dbo.spAddressByCity_local 'Abingdon';
GO
-- This plan is optimal for Abingdon : 1 index scan & 1 Index Seek
-- 218 Logical Reads





-- Demo for Plan Guide

-- Alter Stored procedure for plan guide demo
-- Recreating the Stored procedure clears it from the procedure cache automatically

ALTER PROCEDURE dbo.spAddressByCity_nolocal @City NVARCHAR(30)
AS
BEGIN

SELECT a.AddressID,
a.AddressLine1,
a.AddressLine2,
a.City,
sp.[Name] AS StateProvinceName,
a.PostalCode
FROM Person.Address AS a
JOIN Person.StateProvince AS sp
ON a.StateProvinceID = sp.StateProvinceID
WHERE a.City = @City ;
END;
GO


DBCC FREEPROCCACHE;
GO


EXEC sys.sp_create_plan_guide @name = 'SniffFix', -- sysname
@stmt = N'SELECT a.AddressID,
a.AddressLine1,
a.AddressLine2,
a.City,
sp.[Name] AS StateProvinceName,
a.PostalCode
FROM Person.Address AS a
JOIN Person.StateProvince AS sp
ON a.StateProvinceID = sp.StateProvinceID
WHERE a.City = @City ;', -- nvarchar(max)
@type = N'Object', -- nvarchar(60)
@module_or_batch = N'dbo.spAddressByCity_nolocal', -- nvarchar(max)
@params = NULL, -- nvarchar(max) -- used for template type plan guide
@hints = N'OPTION(OPTIMIZE FOR(@City = ''Abingdon''))' -- nvarchar(max)
;
GO

EXEC dbo.spAddressByCity_nolocal 'Abingdon';
GO
-- This plan is optimal for Abingdon : 1 index scan & 1 Index Seek
-- 218 Logical Reads

EXEC dbo.spAddressByCity_nolocal 'London';
GO
-- This plan is sub optimal for London : 1 Index Scan & 1 Index Seek
-- 1100 logical reads