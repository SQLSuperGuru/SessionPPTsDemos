
-- Demo Scripts Adapted from 
-- SQL SERVER MVP DEEP DIVES, Chapter 8 'Parameter Sniffing: your best friend...except when it isn't'
-- by Grant Fritchey  

-- demo of how parameter sniffing works for queries

USE AdventureWorks2008R2;
GO

-- Include Actual Execution Plan and see the Parameter List on SELECT

-- **!! DO NOT USE FREEPROCCACHE ON PRODUCTION SYSTEMS !!**
DBCC FREEPROCCACHE;
GO

-- AUTO Parameterization in SIMPLE Mode

-- SalesOrderHeader Table has one row per SalesOrderID
SELECT *
FROM	AdventureWorks2008R2.Sales.SalesOrderHeader  
WHERE	SalesOrderID = 56000;
GO
SELECT *
FROM	AdventureWorks2008R2.Sales.SalesOrderHeader
WHERE	SalesOrderID = 56001;
GO

DECLARE @sid INT = 56002 ;
SELECT *
FROM	AdventureWorks2008R2.Sales.SalesOrderHeader
WHERE	SalesOrderID = @sid;
GO

DECLARE @sid INT = 56003 ;
SELECT *
FROM	AdventureWorks2008R2.Sales.SalesOrderHeader
WHERE	SalesOrderID = @sid;
GO

-- Query DMVs for execution plan reuse statistics
SELECT  stats.execution_count AS [Execution_Count], 
	p.size_in_bytes AS [size], 
	[sql].[text] AS [plan_text]
FROM sys.dm_exec_cached_plans p
OUTER APPLY sys.dm_exec_sql_text (p.plan_handle) sql
JOIN sys.dm_exec_query_stats stats 
ON stats.plan_handle = p.plan_handle;
GO

-- This Query will not be AUTO Parameterized in SMIPLE Parameterization mode
DBCC FREEPROCCACHE
GO

SELECT  SUM(LineTotal) AS LineTotal
FROM	Sales.SalesOrderHeader H
JOIN	Sales.SalesOrderDetail D ON D.SalesOrderID = H.SalesOrderID
WHERE	H.SalesOrderID = 56000;
GO

-- Using Explicit Parameterization in this Query
DBCC FREEPROCCACHE
GO

EXEC sp_executesql N'SELECT  SUM(LineTotal) AS LineTotal
FROM	Sales.SalesOrderHeader H
JOIN Sales.SalesOrderDetail D ON D.SalesOrderID = H.SalesOrderID
WHERE	H.SalesOrderID = @SalesOrderID', N'@SalesOrderID INT', 56000;
GO











