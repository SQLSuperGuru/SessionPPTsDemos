
-- Demo Scripts Adapted from 
-- SQL SERVER MVP DEEP DIVES, Chapter 8 'Parameter Sniffing: your best friend...except when it isn't'
-- by Grant Fritchey  

-- demo of uneven data distribution

USE AdventureWorks2008R2;
GO

SELECT 
	City, 
	COUNT(*) AS Rows_per_city
FROM Person.Address
GROUP BY City
ORDER BY City
;
GO

-- Note that Abingdon has 1 row
-- London has 434 rows
-- Majority of the data distribution is less than 20 rows per city

-- Show statistics for this table/column
DBCC SHOW_STATISTICS ( "Person.Address", City) 
-- This Shows the Statistics Header as first result set 
-- Second result set is Density vector ( All Density = 1/Distinct Values)
-- Third Result set is the histogram ( Frequency of occurance of each result in the data set)
-- http://msdn.microsoft.com/en-us/library/ms174384.aspx

DBCC FREEPROCCACHE;
GO

-- Stored procedure not using local variables
CREATE PROCEDURE dbo.spAddressByCity_nolocal @City NVARCHAR(30)
AS
BEGIN

SELECT a.AddressID,
a.AddressLine1,
a.AddressLine2,
a.City,
sp.[Name] AS StateProvinceName,
a.PostalCode
FROM Person.Address AS a
JOIN Person.StateProvince AS sp
ON a.StateProvinceID = sp.StateProvinceID
WHERE a.City = @City ;
END;
GO

SET STATISTICS IO ON

SET STATISTICS TIME ON

-- parameter sniffing at work when no local variables are used

-- optimal plan for selecting few hundred rows : Involves 2 Index Scans
-- Scan (1) & Logical Read counts (218)

DBCC FREEPROCCACHE;
GO

EXEC dbo.spAddressByCity_nolocal 'London';
GO

-- optimal plan for selecting 1 row : Involves 1 index scan & 1 Clustered Index Seek
-- Scan(1) & Logical Read counts (218)

DBCC FREEPROCCACHE;
GO

EXEC dbo.spAddressByCity_nolocal 'Abingdon';
GO

-- sub optimal plan for selecting few hundred rows due to bad parameter sniffing : 
-- Involves 1 Index Scan & 1 Clustered index Seek
-- Scan (1) & Logical Read counts (1100)
EXEC dbo.spAddressByCity_nolocal 'London';
GO
















.

