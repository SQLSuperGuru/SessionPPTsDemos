
-- Demo Scripts Adapted from 
-- SQL SERVER MVP DEEP DIVES, Chapter 8 'Parameter Sniffing: your best friend...except when it isn't'
-- by Grant Fritchey  

-- Demo for RECOMPILE

USE AdventureWorks2008R2;
GO

-- Alter Stored procedure to RECOMPILE
-- Recreating the Stored procedure clears it from the procedure cache automatically

ALTER PROCEDURE dbo.spAddressByCity_nolocal @City NVARCHAR(30)
AS
BEGIN

SELECT a.AddressID,
a.AddressLine1,
a.AddressLine2,
a.City,
sp.[Name] AS StateProvinceName,
a.PostalCode
FROM Person.Address AS a
JOIN Person.StateProvince AS sp
ON a.StateProvinceID = sp.StateProvinceID
WHERE a.City = @City
OPTION (RECOMPILE) ;
END;
GO

ALTER PROCEDURE dbo.spAddressByCity_nolocal @City NVARCHAR(30)
WITH RECOMPILE
AS
BEGIN

SELECT a.AddressID,
a.AddressLine1,
a.AddressLine2,
a.City,
sp.[Name] AS StateProvinceName,
a.PostalCode
FROM Person.Address AS a
JOIN Person.StateProvince AS sp
ON a.StateProvinceID = sp.StateProvinceID
WHERE a.City = @City ;
END;
GO

DBCC FREEPROCCACHE;
GO

SET STATISTICS IO ON

SET STATISTICS TIME ON

EXEC dbo.spAddressByCity_nolocal 'Abingdon';
GO
-- optimal plan for Abingdon with 1 index scan & 1 index seek
-- 218 logical reads

EXEC dbo.spAddressByCity_nolocal 'London';
GO
-- optimal plan for London with 2 index scans
-- 219 logical reads