
-- Demo Scripts Adapted from 
-- SQL SERVER MVP DEEP DIVES, Chapter 8 'Parameter Sniffing: your best friend...except when it isn't'
-- by Grant Fritchey  

USE AdventureWorks2008R2;
GO

-- turn off parameter sniffing

DBCC TRACEON (4136,-1);
-- turning the trace flag ON will turn Parameter Sniffing OFF

-- drop plan guide

EXEC sys.sp_control_plan_guide
	@operation = N'DROP',
	@name = SniffFix;
GO	

ALTER PROCEDURE dbo.spAddressByCity_nolocal @City NVARCHAR(30)
AS
BEGIN

SELECT a.AddressID,
a.AddressLine1,
a.AddressLine2,
a.City,
sp.[Name] AS StateProvinceName,
a.PostalCode
FROM Person.Address AS a
JOIN Person.StateProvince AS sp
ON a.StateProvinceID = sp.StateProvinceID
WHERE a.City = @City ;
END;
GO


DBCC FREEPROCCACHE;
GO

-- optimizer will generate an execution plan that it thinks is best suited for majority of data
-- similar to using OPTIMIZE FOR UNKNOWN Hint , or using Local Variables

-- Execution plan shows that no parameter sniffing is happening
EXEC dbo.spAddressByCity_nolocal 'Abingdon';
GO

EXEC dbo.spAddressByCity_nolocal 'London';
GO

DBCC TRACEOFF (4136,-1);
-- turning the trace flag OFF will turn Parameter Sniffing back ON

DBCC FREEPROCCACHE;
GO

EXEC dbo.spAddressByCity_nolocal 'London';
GO
-- Execution plan shows that parameter sniffing is turned back on

