
-- Demo Scripts Adapted from 
-- SQL SERVER MVP DEEP DIVES, Chapter 8 'Parameter Sniffing: your best friend...except when it isn't'
-- by Grant Fritchey  

-- cleanup

USE AdventureWorks2008R2;
GO

-- drop plan guide

EXEC sys.sp_control_plan_guide
	@operation = N'DROP',
	@name = SniffFix;
GO	

DROP PROCEDURE dbo.spAddressByCity_nolocal;
GO

DROP PROCEDURE dbo.spAddressByCity_local;
GO


DBCC FREEPROCCACHE;
GO
