
-- Demo Scripts Adapted from 
-- SQL SERVER MVP DEEP DIVES, Chapter 8 'Parameter Sniffing: your best friend...except when it isn't'
-- by Grant Fritchey  

-- Demo of Optimize for Value

USE AdventureWorks2008R2;
GO

DBCC FREEPROCCACHE;
GO


-- Alter Stored procedure to use optimize for value
-- Recreating the Stored procedure clears it from the procedure cache automatically

ALTER PROCEDURE dbo.spAddressByCity_nolocal @City NVARCHAR(30)
AS
BEGIN

SELECT a.AddressID,
a.AddressLine1,
a.AddressLine2,
a.City,
sp.[Name] AS StateProvinceName,
a.PostalCode
FROM Person.Address AS a
JOIN Person.StateProvince AS sp
ON a.StateProvinceID = sp.StateProvinceID
WHERE a.City = @City 
OPTION (OPTIMIZE FOR (@City = 'Abingdon'));
END;
GO

SET STATISTICS IO ON

SET STATISTICS TIME ON

EXEC dbo.spAddressByCity_nolocal 'Abingdon';
GO
-- optimal plan for Abingdon
-- 1 Index Scan & 1 Clustered Seek
-- 218 Logical Reads

EXEC dbo.spAddressByCity_nolocal 'London';
GO
-- sub optimal plan for London
-- 1 Index Scan & 1 Clustered Seek
-- 1100 Logical Reads

-- Demo of Optimize for Unknown

ALTER PROCEDURE dbo.spAddressByCity_nolocal @City NVARCHAR(30)
AS
BEGIN

SELECT a.AddressID,
a.AddressLine1,
a.AddressLine2,
a.City,
sp.[Name] AS StateProvinceName,
a.PostalCode
FROM Person.Address AS a
JOIN Person.StateProvince AS sp
ON a.StateProvinceID = sp.StateProvinceID
WHERE a.City = @City 
OPTION (OPTIMIZE FOR (@City UNKNOWN));
END;
GO

EXEC dbo.spAddressByCity_nolocal 'Abingdon';
GO
-- optimal plan for Abingdon
-- 1 Index Scan & 1 Clustered Seek
-- 218 Logical Reads

EXEC dbo.spAddressByCity_nolocal 'London';
GO
-- sub optimal plan for London
-- 1 Index Scan & 1 Clustered Seek
-- 1100 Logical Reads