
-- Demo to set up Service Broker with manual activation & two way messaging

USE sbq_demo;
GO

-- Create Request Message Type
CREATE MESSAGE TYPE
[manual_activation_demo_request]
VALIDATION = WELL_FORMED_XML;
GO

-- Create Response Message Type
CREATE MESSAGE TYPE
[manual_activation_demo_response]
VALIDATION = WELL_FORMED_XML;
GO

-- Create Contract
CREATE CONTRACT [manual_activation_contract]
(
[manual_activation_demo_request] SENT BY INITIATOR,
[manual_activation_demo_response] SENT BY TARGET
);
GO

-- Create Initiator Queue
CREATE QUEUE [manual_activation_initiator_queue]
WITH STATUS = ON;
GO

-- Create Traget Queue
CREATE QUEUE [manual_activation_target_queue]
WITH STATUS = ON;
GO

-- Create Initiator Service
CREATE SERVICE [manual_activation_initiator_service]
ON QUEUE [manual_activation_initiator_queue] 
(
[manual_activation_contract]
);
GO

-- Create Target Service
CREATE SERVICE [manual_activation_target_service]
ON QUEUE [manual_activation_target_queue] 
(
[manual_activation_contract]
);
GO

-- Create SP to send request message on Queue
CREATE PROCEDURE dbo.usp_manual_activation_send_message_on_initiator @msg NVARCHAR(MAX)
AS
BEGIN

DECLARE @ch UNIQUEIDENTIFIER,
		@l_error INT;

BEGIN TRANSACTION 

	BEGIN DIALOG CONVERSATION @ch
		  FROM SERVICE [manual_activation_initiator_service]
		  TO SERVICE 'manual_activation_target_service'
		  ON CONTRACT [manual_activation_contract]
		  WITH ENCRYPTION = OFF ;
		  
		  SET @l_error = @@ERROR;
		  IF @l_error <> 0
			GOTO FINISHED;
		  
	SEND ON CONVERSATION @ch
		MESSAGE TYPE [manual_activation_demo_request]
		(@msg);
		
		  SET @l_error = @@ERROR;
		  IF @l_error <> 0
			GOTO FINISHED;
				
FINISHED:

	IF @l_error = 0 
		COMMIT TRANSACTION
	ELSE
		ROLLBACK TRANSACTION	

RETURN @l_error;
	
END;
GO

-- EXEC dbo.usp_manual_activation_send_message_on_initiator @msg = '<DemoRequest>Manual Activation Demo Request</DemoRequest>' ;

-- Create SP to recieve message on traget queue and send a response back to initiator 

CREATE PROCEDURE dbo.usp_manual_activation_recieve_message_on_target 
AS
BEGIN

DECLARE @ch UNIQUEIDENTIFIER,
		 @messagetypename NVARCHAR(256),
		 @messagebody XML,
		 @responsemessage XML;

WAITFOR (
	RECEIVE TOP(1)
		@ch = conversation_handle,
		@messagetypename = message_type_name,
		@messagebody = CAST(message_body AS XML)
	FROM manual_activation_target_queue),
TIMEOUT 5000; -- Wait for 5 secs for message to appear on Queue

SELECT 'Conversation handle: ' + CAST(@ch AS NVARCHAR(MAX));
SELECT 'Message type: ' + @messagetypename;
SELECT 'Message body: ' + CAST(@messagebody AS NVARCHAR(MAX));

IF ( @messagetypename = 'manual_activation_demo_request' ) 
    BEGIN
-- Construct the response message
        SET @responsemessage = '<DemoResponse>SBQ Manual Activation Demo Response, '
            + @messagebody.value('/DemoRequest[1]', 'NVARCHAR(MAX)')
            + '</DemoResponse>' ;

-- Send the response message back to the initiating service
        SEND ON CONVERSATION @ch MESSAGE TYPE [manual_activation_demo_response] (@responsemessage) ;

-- End the conversation on the target's side
        END CONVERSATION @ch ;
    END

RETURN @@ERROR;

END;
GO

-- EXEC dbo.usp_manual_activation_recieve_message_on_target

-- Create SP to recieve response message at initiator

CREATE PROCEDURE dbo.usp_manual_activation_recieve_response_on_initiator 
AS
BEGIN

DECLARE @ch UNIQUEIDENTIFIER,
		 @messagetypename NVARCHAR(256),
		 @messagebody XML;

WAITFOR (
	RECEIVE TOP(1)
		@ch = conversation_handle,
		@messagetypename = message_type_name,
		@messagebody = CAST(message_body AS XML)
	FROM manual_activation_initiator_queue),
TIMEOUT 100;

IF ( @messagetypename = 'manual_activation_demo_response' ) 
    BEGIN
        SELECT 'Conversation handle: ' + CAST(@ch AS NVARCHAR(MAX))
        SELECT 'Message type: ' + @messagetypename
        SELECT 'Message body: ' + CAST(@messagebody AS NVARCHAR(MAX))
    END

IF ( @messagetypename = 'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog' ) 
    BEGIN
-- End the conversation on the initiator's side
        END CONVERSATION @ch ;
    END

RETURN @@ERROR;
    
END;
GO

-- EXEC dbo.usp_manual_activation_recieve_response_on_initiator

