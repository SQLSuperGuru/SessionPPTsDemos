USE sbq_demo;
GO

-- Demo to setup automatic activation

-- Create table to insert rows based on message extracted from target queue
CREATE TABLE sbq_stage_recvd_message
	( parsed_rcvd_message NVARCHAR(120),
	  rcvd_msg_type_name NVARCHAR(120),	
	  insert_datetime DATETIME );
GO

-- Create Request Message Type
CREATE MESSAGE TYPE
[automatic_activation_demo_request]
VALIDATION = WELL_FORMED_XML;
GO

-- Create Response Message Type
CREATE MESSAGE TYPE
[automatic_activation_demo_response]
VALIDATION = WELL_FORMED_XML;
GO

-- Create Contract
CREATE CONTRACT [automatic_activation_contract]
(
[automatic_activation_demo_request] SENT BY INITIATOR,
[automatic_activation_demo_response] SENT BY TARGET
);
GO

-- Create Initiator Queue
CREATE QUEUE [automatic_activation_initiator_queue]
WITH STATUS = ON;
GO

-- Create Target Queue
CREATE QUEUE [automatic_activation_target_queue]
WITH STATUS = ON;
GO

-- Create Initiator Service
CREATE SERVICE [automatic_activation_initiator_service]
ON QUEUE [automatic_activation_initiator_queue] 
(
[automatic_activation_contract]
);
GO

-- Create Target Service
CREATE SERVICE [automatic_activation_target_service]
ON QUEUE [automatic_activation_target_queue] 
(
[automatic_activation_contract]
);
GO

-- Create SP to send request message on Queue
CREATE PROCEDURE dbo.usp_automatic_activation_send_message_on_initiator @msg_string NVARCHAR(MAX)
AS
BEGIN

DECLARE @ch UNIQUEIDENTIFIER,
		@l_error INT,
		@msg XML;
		
-- Create the XML message

SELECT @msg = '<DemoRequest>'+ @msg_string +'</DemoRequest>'

BEGIN TRANSACTION 

	BEGIN DIALOG CONVERSATION @ch
		  FROM SERVICE [automatic_activation_initiator_service]
		  TO SERVICE 'automatic_activation_target_service'
		  ON CONTRACT [automatic_activation_contract]
		  WITH ENCRYPTION = OFF ;
		  
		  SET @l_error = @@ERROR;
		  IF @l_error <> 0
			GOTO FINISHED;
		  
	SEND ON CONVERSATION @ch
		MESSAGE TYPE [automatic_activation_demo_request]
		(@msg);
		
		  SET @l_error = @@ERROR;
		  IF @l_error <> 0
			GOTO FINISHED;
				
FINISHED:

	IF @l_error = 0 
		COMMIT TRANSACTION
	ELSE
		ROLLBACK TRANSACTION	

RETURN @l_error;
	
END;
GO


-- Create activation SP to process message on target
CREATE PROCEDURE dbo.usp_automatic_activation_process_message_on_target
AS
BEGIN
  DECLARE @ReceivedRequestDlgHandle UNIQUEIDENTIFIER,
   @ReceivedRequestMessage XML,
   @ReceivedRequestMessageType SYSNAME,
   @ParsedMessageBody NVARCHAR(120);
   
  WHILE (1=1)
      BEGIN
        BEGIN TRANSACTION
        WAITFOR -- Pop the request queue and retrieve the request
         (
          RECEIVE TOP(1)
            @ReceivedRequestDlgHandle = conversation_handle,
            @ReceivedRequestMessage = message_body,
            @ReceivedRequestMessageType = message_type_name
            FROM automatic_activation_target_queue
          ), TIMEOUT 5000;
          IF (@@ROWCOUNT = 0)
            BEGIN
              ROLLBACK
              BREAK
            END
          IF @ReceivedRequestMessageType =
                   N'automatic_activation_demo_request'
            BEGIN
              DECLARE @ReturnMessage XML;
              DECLARE @ReplyMessage XML;
              
              SELECT @ParsedMessageBody = @ReceivedRequestMessage.value('/DemoRequest[1]', 'NVARCHAR(MAX)')
			  -- Insert into table
			  INSERT INTO sbq_stage_recvd_message
					( parsed_rcvd_message,
							rcvd_msg_type_name,
							insert_datetime)
			  SELECT 	@ParsedMessageBody,
						@ReceivedRequestMessageType,
						GETDATE()
							
              -- Send reply with results.
              SET @ReplyMessage = (
                SELECT @ReceivedRequestMessage, 
                                       @ReplyMessage FOR XML PATH('ExecutionComplete'));
              SEND ON CONVERSATION @ReceivedRequestDlgHandle
              MESSAGE TYPE [automatic_activation_demo_response]
                  ( @ReplyMessage );
                  
               END CONVERSATION @ReceivedRequestDlgHandle;
               
            END
            ELSE IF @ReceivedRequestMessageType = 
                              N'http://schemas.microsoft.com/SQL/ServiceBroker/EndDialog'
             OR @ReceivedRequestMessageType = 
                              N'http://schemas.microsoft.com/SQL/ServiceBroker/Error'
            BEGIN
              END CONVERSATION @ReceivedRequestDlgHandle
            END
            COMMIT
       END
END;
GO


-- Alter Target Queue for internal activation
ALTER QUEUE [automatic_activation_target_queue]
WITH ACTIVATION
(
   STATUS = ON,
   PROCEDURE_NAME = dbo.usp_automatic_activation_process_message_on_target,
   MAX_QUEUE_READERS = 20,
   EXECUTE AS OWNER
);
GO



-- Create SP for displaying the response

CREATE PROCEDURE dbo.usp_display_response
AS
BEGIN
  SET NOCOUNT ON
  DECLARE @ReceivedDlgHandle UNIQUEIDENTIFIER,
   @ReceivedReplyMessage XML,
   @ReceivedReplyMessageType SYSNAME;
  WHILE (1=1)
    BEGIN
      BEGIN TRANSACTION
      WAITFOR -- Pop the queue to get the next message for processing
       (
        RECEIVE TOP(1)
          @ReceivedDlgHandle = conversation_handle,
          @ReceivedReplyMessage = message_body,
          @ReceivedReplyMessageType = message_type_name
         FROM [automatic_activation_initiator_queue]
        ),TIMEOUT 5000;
        IF (@@ROWCOUNT= 0)
          BEGIN
            ROLLBACK
            BREAK
          END
        IF @ReceivedReplyMessageType =
                  N'automatic_activation_demo_response'
          BEGIN
				SELECT 'Conversation handle: ' + CAST(@ReceivedDlgHandle AS NVARCHAR(MAX));
				SELECT 'Message type: ' + @ReceivedReplyMessageType;
				SELECT 'Message body: ' + CAST(@ReceivedReplyMessage AS NVARCHAR(MAX));
            END CONVERSATION @ReceivedDlgHandle;
          END
        COMMIT
    END
END;
GO

-- set up conversation priorities. This feature is not available in SQL Server 2005 !

USE sbq_demo;
GO
CREATE BROKER PRIORITY ManualActivationPriority
    FOR CONVERSATION
    SET (CONTRACT_NAME = manual_activation_contract,
         LOCAL_SERVICE_NAME = manual_activation_initiator_service,
         REMOTE_SERVICE_NAME = N'manual_activation_target_service',
         PRIORITY_LEVEL = 6);
GO

CREATE BROKER PRIORITY AutomaticActivationPriority
    FOR CONVERSATION
    SET (CONTRACT_NAME = automatic_activation_contract,
         LOCAL_SERVICE_NAME = automatic_activation_initiator_service,
         REMOTE_SERVICE_NAME = N'automatic_activation_target_service',
         PRIORITY_LEVEL = 3);
GO

-- sys.conversation_priorities catalog view

SELECT scp.name AS priority_name,
       ssc.name AS contract_name,
       ssvc.name AS local_service_name,
       scp.remote_service_name,
       scp.priority AS priority_level
FROM sys.conversation_priorities AS scp
    INNER JOIN sys.service_contracts AS ssc
       ON scp.service_contract_id = ssc.service_contract_id
    INNER JOIN sys.services AS ssvc
       ON scp.local_service_id = ssvc.service_id
ORDER BY priority_name, contract_name,
         local_service_name, remote_service_name;


GO








           
           

