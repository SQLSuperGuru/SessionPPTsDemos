USE sbq_demo;
GO

-- Demo of Catalog View  

SELECT * FROM sys.service_message_types;

SELECT * FROM sys.service_queues;
-- is_queue_enabled

SELECT * FROM sys.conversation_endpoints;
-- state_desc

SELECT * FROM sys.transmission_queue;
-- transmission_status

-- Demo of Poison message & Queue disabling

-- Put Message on the Queue
EXEC dbo.usp_manual_activation_send_message_on_initiator 
	@msg = '<DemoRequest>Manual Activation Demo Request</DemoRequest>' ;
GO

-- Begin transaction and recieve message from Queue & 
-- rollback transaction more than 5 times by executing this block 5 times !
BEGIN TRANSACTION

EXEC dbo.usp_manual_activation_recieve_message_on_target ;

ROLLBACK TRANSACTION

-- Enable the Queue
ALTER QUEUE manual_activation_target_queue WITH STATUS = ON;

-- Get Response back out from the Queue
EXEC dbo.usp_manual_activation_recieve_response_on_initiator ;
GO

-- manually END conversation that has a permenant problem

-- Create Poison Message
-- Check SELECT * FROM sys.conversation_endpoints;
-- END Conversation
-- ENABLE QUEUE

BEGIN
DECLARE @ch UNIQUEIDENTIFIER;

SELECT TOP 1 @ch = conversation_handle FROM sys.conversation_endpoints
WHERE far_service = 'manual_activation_target_service'

END CONVERSATION @ch WITH CLEANUP;

END

-- Disable the Queue for SSBDiagnose Demo
ALTER QUEUE manual_activation_target_queue WITH STATUS = OFF;







