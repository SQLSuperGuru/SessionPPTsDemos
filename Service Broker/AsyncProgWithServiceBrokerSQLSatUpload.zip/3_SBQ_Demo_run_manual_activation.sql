USE sbq_demo;
GO

SET NOCOUNT ON;
GO

-- Demo to run the example for manual activation

EXEC dbo.usp_manual_activation_send_message_on_initiator 
	@msg = '<DemoRequest>Manual Activation Demo Request</DemoRequest>' ;
GO

EXEC dbo.usp_manual_activation_recieve_message_on_target ;
GO

EXEC dbo.usp_manual_activation_recieve_response_on_initiator ;
GO
