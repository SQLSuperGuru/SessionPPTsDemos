USE sbq_demo;
GO

-- look at the staging table
SELECT * FROM sbq_stage_recvd_message;
GO

-- Put message on the Queue
EXEC dbo.usp_automatic_activation_send_message_on_initiator 
@msg_string = 'Automatic Activation Demo Request' ;

-- look at the staging table again
SELECT * FROM sbq_stage_recvd_message;
GO

-- Get response back from Queue
EXEC dbo.usp_display_response;
GO

-- look at the staging table again
SELECT * FROM sbq_stage_recvd_message;
GO
