

USE master
GO

IF EXISTS ( SELECT  *
            FROM    sys.databases
            WHERE   name = 'sbq_demo' ) 
    BEGIN
        PRINT 'Dropping database ''sbq_demo''' ;
        DROP DATABASE sbq_demo ;
    END
GO

CREATE DATABASE sbq_demo
GO



-- check if service broker is enabled in your database

SELECT 
	name
	,is_broker_enabled
	,service_broker_guid
 FROM sys.databases
 ORDER BY name;
 
--  turn on service broker 

ALTER DATABASE sbq_demo SET ENABLE_BROKER WITH ROLLBACK IMMEDIATE;

--  turn off service broker 

ALTER DATABASE sbq_demo SET DISABLE_BROKER WITH ROLLBACK IMMEDIATE;

-- WITH ROLLBACK IMMEDIATE is optional. If used, it will rollback & close every transaction currently
-- running in your database.